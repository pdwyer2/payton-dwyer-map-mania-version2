# payton-dwyer-map-mania-version1-part2
Author: Payton Dwyer
Course: Web and Distributed Prog


Source for google maps polyline between two markers and distance calculation between two points. Link: https://cloud.google.com/blog/products/maps-platform/how-calculate-distances-map-maps-javascript-api
